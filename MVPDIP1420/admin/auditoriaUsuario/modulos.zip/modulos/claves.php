<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php

		if($operacion=="Insert"){
			$sql="SELECT * FROM claves_historicos  WHERE id_clave ='{$id}' AND fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['usuario']);
			unset($row['forma_usuario']);
			unset($row['id_clave']);
			unset($row['referencia_importacion']);
			unset($row['fechaR']);
			$rowx=$row;
		}
		if($operacion=="Update"){
			$sql="SELECT * FROM claves_historicos  WHERE id_clave ='{$id}' AND fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['referencia_importacion']);
			unset($row['fechaR']);
			unset($row['id']);
			unset($row['id_clave']);
			unset($row['codigo_plataforma']);

			$sql="SELECT * FROM claves_historicos  WHERE id_clave ='{$id}' AND fechaR<'{$fechaR}' ORDER BY fechaR DESC ";
			$resultado = $conexion->query($sql);
			$rowx=$resultado->fetch_assoc();
			foreach($rowx as $key => $value){
				if(is_numeric($key)) unset($rowx[$key]);
			}
			//var_dump($row);
			unset($rowx['referencia_importacion']);
			unset($rowx['fechaR']);
			unset($rowx['id']);
			unset($rowx['id_clave']);
			unset($rowx['codigo_plataforma']);
		}
		?>
		<br>
		<?php
			echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>Actual</label></div>";
			foreach ($row as $key => $value) {
				echo '<label class="labelForm">';
				if($rowx[$key]!=$value){
					$color="color:red;";
				}else{
					$color="";
				}
				$key=str_replace("_"," ",$key); 
				echo "<font style='font-size: 10px;'>{$key}:</font>";
				echo '</label>';
				echo '<label class="descripcionForm">'; 
				
				echo "<font style='font-size: 10px;{$color}'>{$value}</font>";
				echo '</label>';
				echo "<br>";
			}
		?>
		<hr>

		<?php
			if($operacion=="Update"){
				echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>Anterior</label></div>";
				foreach ($rowx as $key => $value) {
					echo '<label class="labelForm">';
					$key=str_replace("_"," ",$key); 
					echo "<font style='font-size: 10px;'>{$key}:</font>";
					echo '</label>';
					echo '<label class="descripcionForm">'; 
					echo "<font style='font-size: 10px;'>{$value}</font>";
					echo '</label>';
					echo "<br>";
				}
			}
		?>

	</div>
</div>