<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php
		function password($password){
			$len = strlen($password);
			$return="";
			for ($i=0; $i < $len ; $i++) { 
				$return.="*";
			}
			return $return;
		}
		if($operacion=="Insert"){
			$sql="
			SELECT * ,
			(SELECT p.nombre FROM proveedores p WHERE p.id=cp.id_proveedor) proveedor,
			(SELECT clave FROM ventas vt WHERE vt.id=cp.id_venta_saldo) venta,
			(SELECT b.nombre FROM bancos b WHERE b.id=cp.id_banco) nombre_banco, 
			(SELECT tp.nombre FROM tipos_pagos tp WHERE tp.id=cp.id_tipo_pago) nombre_tipo_pago,
			(SELECT tp.nombre FROM sucursales tp WHERE tp.id=cp.id_sucursal) sucursal
			FROM cobros_proveedores_historicos cp  WHERE cp.id_cobro_proveedor ='{$id}' AND cp.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			$row['monto']=number_format($row['monto'],2,'.',',');
			$row['monto_total']=number_format($row['monto_total'],2,'.',',');
			unset($row['id']);
			unset($row['id_cobro_proveedor']);
			unset($row['id_venta_saldo']);
			unset($row['id_tipo_pago']);
			unset($row['id_banco']);
			unset($row['id_terminal']);
			unset($row['comision_terminal']);
			unset($row['monto_comision']);
			unset($row['fecha_hora']);
			unset($row['id_sucursal']);
			unset($row['id_proveedor']);

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']); 
			$rowx=$row;
		}
		if($operacion=="Update"){
			$sql="
			SELECT * ,
			(SELECT p.nombre FROM proveedores p WHERE p.id=cp.id_proveedor) proveedor,
			(SELECT clave FROM ventas vt WHERE vt.id=cp.id_venta_saldo) venta,
			(SELECT b.nombre FROM bancos b WHERE b.id=cp.id_banco) nombre_banco, 
			(SELECT tp.nombre FROM tipos_pagos tp WHERE tp.id=cp.id_tipo_pago) nombre_tipo_pago,
			(SELECT tp.nombre FROM sucursales tp WHERE tp.id=cp.id_sucursal) sucursal
			FROM cobros_proveedores_historicos cp  WHERE cp.id_cobro_proveedor ='{$id}' AND cp.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			$row['monto']=number_format($row['monto'],2,'.',',');
			$row['monto_total']=number_format($row['monto_total'],2,'.',',');
			unset($row['id']);
			unset($row['id_cobro_proveedor']);
			unset($row['id_venta_saldo']);
			unset($row['id_tipo_pago']);
			unset($row['id_banco']);
			unset($row['id_terminal']);
			unset($row['comision_terminal']);
			unset($row['monto_comision']);
			unset($row['fecha_hora']);
			unset($row['id_sucursal']);
			unset($row['id_proveedor']);

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']);


			$sql="
			SELECT * ,
			(SELECT p.nombre FROM proveedores p WHERE p.id=cp.id_proveedor) proveedor,
			(SELECT clave FROM ventas vt WHERE vt.id=cp.id_venta_saldo) venta,
			(SELECT b.nombre FROM bancos b WHERE b.id=cp.id_banco) nombre_banco, 
			(SELECT tp.nombre FROM tipos_pagos tp WHERE tp.id=cp.id_tipo_pago) nombre_tipo_pago,
			(SELECT tp.nombre FROM sucursales tp WHERE tp.id=cp.id_sucursal) sucursal
			FROM cobros_proveedores_historicos cp  WHERE cp.id_cobro_proveedor ='{$id}' AND cp.fechaR<'{$fechaR}' ORDER BY cp.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$rowx=$resultado->fetch_assoc();
			foreach($rowx as $key => $value){
				if(is_numeric($key)) unset($rowx[$key]);
			}
			//var_dump($row);
			$rowx['monto']=number_format($rowx['monto'],2,'.',',');
			$rowx['monto_total']=number_format($rowx['monto_total'],2,'.',',');
			unset($rowx['id']);
			unset($rowx['id_cobro_proveedor']);
			unset($rowx['id_venta_saldo']);
			unset($rowx['id_tipo_pago']);
			unset($rowx['id_banco']);
			unset($rowx['id_terminal']);
			unset($rowx['comision_terminal']);
			unset($rowx['monto_comision']);
			unset($rowx['fecha_hora']);
			unset($rowx['id_sucursal']);
			unset($rowx['id_proveedor']);

			unset($rowx['referencia_importacion']);
			unset($rowx['codigo_plataforma']);
			unset($rowx['fechaR']);
		}
		if($operacion=="Delete"){
			$sql="
			SELECT * ,
			(SELECT p.nombre FROM proveedores p WHERE p.id=cp.id_proveedor) proveedor,
			(SELECT clave FROM ventas vt WHERE vt.id=cp.id_venta_saldo) venta,
			(SELECT b.nombre FROM bancos b WHERE b.id=cp.id_banco) nombre_banco, 
			(SELECT tp.nombre FROM tipos_pagos tp WHERE tp.id=cp.id_tipo_pago) nombre_tipo_pago,
			(SELECT tp.nombre FROM sucursales tp WHERE tp.id=cp.id_sucursal) sucursal
			FROM cobros_proveedores_historicos cp  WHERE cp.id_cobro_proveedor ='{$id}' AND cp.fechaR<'{$fechaR}' ORDER BY cp.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			$row['monto']=number_format($row['monto'],2,'.',',');
			$row['monto_total']=number_format($row['monto_total'],2,'.',',');
			unset($row['id']);
			unset($row['id_cobro_proveedor']);
			unset($row['id_venta_saldo']);
			unset($row['id_tipo_pago']);
			unset($row['id_banco']);
			unset($row['id_terminal']);
			unset($row['comision_terminal']);
			unset($row['monto_comision']);
			unset($row['fecha_hora']);
			unset($row['id_sucursal']);
			unset($row['id_proveedor']);

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']);
			$rowx=$row;
		}
		?>
		<br>
		<?php
			if($operacion=="Delete"){
				$tipoRegistro="Borrado";
			}else{
				$tipoRegistro="Actual";
			}
			echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>{$tipoRegistro}</label></div>";
			foreach ($row as $key => $value) {
				echo '<label class="labelForm">';
				if($rowx[$key]!=$value){
					$color="color:red;";
				}else{
					$color="";
				}
				if($key=='password'){
					$value=password($value);
				}
				$key=str_replace("_"," ",$key); 
				echo "<font style='font-size: 10px;'>{$key}:</font>";
				echo '</label>';
				echo '<label class="descripcionForm">'; 
				
				echo "<font style='font-size: 10px;{$color}'>{$value}</font>";
				echo '</label>';
				echo "<br>";
			}
		?>
		<hr>

		<?php
			if($operacion=="Update"){
				echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>Anterior</label></div>";
				foreach ($rowx as $key => $value) {
					if($key=='password'){
						$value=password($value);
					}
					echo '<label class="labelForm">';
					$key=str_replace("_"," ",$key); 
					echo "<font style='font-size: 10px;'>{$key}:</font>";
					echo '</label>';
					echo '<label class="descripcionForm">'; 
					echo "<font style='font-size: 10px;'>{$value}</font>";
					echo '</label>';
					echo "<br>";
				}
			}
		?>

	</div>
</div>