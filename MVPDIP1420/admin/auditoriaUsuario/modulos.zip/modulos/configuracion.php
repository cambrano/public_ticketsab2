<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php

		if($operacion=="Insert"){
			$sql="SELECT * FROM configuracion ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['referencia_importacion']);
			unset($row['fechaR']);
			unset($row['logo']);
			unset($row['codigo_plataforma']);
		}
		if($operacion=="Update"){
			$sql="SELECT * FROM configuracion ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['referencia_importacion']);
			unset($row['fechaR']);
			unset($row['logo']);
			unset($row['codigo_plataforma']);
		}
		?>
		<label class="labelForm" id="labeltemaname">Configuración</label><br>
		<?php
			foreach ($row as $key => $value) {
				echo '<label class="labelForm">';
				$key=str_replace("_"," ",$key); 
				echo "<font style='font-size: 10px;'>{$key}:</font>";
				echo '</label>';
				echo '<label class="descripcionForm">'; 
				echo "<font style='font-size: 10px;'>{$value}</font>";
				echo '</label>';
				echo "<br>";
			}
		?>

	</div>
</div>