<script type="text/javascript">
	$(document).ready(function() {
		var dataTable = $('#importacion-tabla').DataTable( {
			"responsive": true,
			"ordering": false,
			"pageLength": 11,
			"retrieve": true,
			"info": false,
			"processing": true,
			"searching": false,
			"paging": false,
			"sPaginationType": "full_numbers",
			"order": [[ 0, "desc" ]],
			"fixedHeader": true,
			"fixedHeader": {
				header: true,
			},
			"aoColumnDefs": [
							{ "bSortable": false, "aTargets": [ 1 ] }
							],
			"serverSide": false,
			"scrollY": "100%", 
			"scrollX": "100%",

			"language": {
				"sProcessing":     "Procesando...",
				//"sLengthMenu":     "Mostrar _MENU_ registros",
				"sLengthMenu": ' ',
				"sSearch":         "Buscar:",
				"sZeroRecords":    "Registro no encontrados",
				"sEmptyTable":     "No Existe Registros",
				"sInfo":           "Mostrar  (_START_ a _END_) de _TOTAL_ Registros",//
				"sInfoEmpty":      "Mostrando Registros del 0 al 0 de Total de 0 Registros",//
				"sInfoFiltered":   "(Filtrado de _MAX_ Total Registros)",//
				//"sInfoPostFix":    "",
				//"sUrl":            "",
				//"sInfoThousands":  ",",
				"sLoadingRecords": "Cargando...",
				"oPaginate": {
					"sFirst":    "<<",
					"sLast":     ">>",
					"sNext":     ">",
					"sPrevious": "<"
				},
				"oAria": {
					"sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
					"sSortDescending": ": Activar para ordenar la columna de manera descendente"
				},
			},
		});
	});
</script>
<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php
		$sql="SELECT * FROM log_importaciones WHERE id='{$id}' ";
		$resultado = $conexion->query($sql);
		$row=$resultado->fetch_assoc();
		foreach($row as $key => $value){
			if(is_numeric($key)) unset($row[$key]);
		}
		$file="../importacionesSistema/files/".strtolower($row['tipo'])."_".$row['id_usuario']."_".$row['tabla']."_".$row['referencia_importacion'].".csv";
		$tabla=$row['tabla'];
		?>
		<label class="labelForm" id="labeltemaname"><?= moduloNombreLog($tabla) ?></label><br>

		<?php
		
	if($tabla=="sucursales"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
					'rfc' =>array('alfanumerico','requerido','mayuscula'),
					'telefono'=>array('telefono','requerido'),
					'celular'=>array('telefono','requerido'),
					'correo_electronico'=>array('correo_electronico','requerido'),
					'pais'=>array('alfanumerico','requerido'),
					'estado'=>array('alfanumerico','requerido'),
					'municipio'=>array('alfanumerico','requerido'),
					'localidad'=>array('alfanumerico','requerido'),
					'calle'=>array('alfanumerico','requerido'),
					'colonia'=>array('alfanumerico','requerido'),
					'codigo_postal'=>array('numerico','requerido'),
				);
	}
	if($tabla=="clientes"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'fecha_nacimiento'=>array('fecha','requerido'),
					'nombre' =>array('alfanumerico','requerido'),
					'apellido_paterno' =>array('alfanumerico','requerido'),
					'apellido_materno' =>array('alfanumerico','requerido'),
					'correo_electronico'=>array('correo_electronico','requerido'),
					'telefono'=>array('telefono','requerido'),
					'celular'=>array('telefono','requerido'),
					'whatsapp'=>array('telefono','requerido'),
				);
	}

	if($tabla=="configuracion"){
		$columnData = array(
					'nombre'=>array('alfanumerico','requerido'),
					'razon_social'=>array('alfanumerico',''),
					'slogan'=>array('alfanumerico',''),
					'registro_nacional_turismo'=>array('alfanumerico','','mayuscula'),
					'nombre_completo_representante'=>array('slogan','requerido'),
					'telefono'=>array('telefono','requerido'),
					'correo_electronico'=>array('correo_electronico','requerido'),
				);
	}
	if($tabla=="claves"){
		$columnData = array(
					'empleado'=>array('alfanumerico','requerido','mayuscula'),
					'forma_empleado'=>array('alfanumerico','requerido','forma'),
					'sucursal'=>array('alfanumerico','requerido','mayuscula'),
					'forma_sucursal'=>array('alfanumerico','requerido','forma'),
					'cliente'=>array('alfanumerico','requerido','mayuscula'),
					'forma_cliente'=>array('alfanumerico','requerido','forma'),
					'banco'=>array('alfanumerico','requerido','mayuscula'),
					'forma_banco'=>array('alfanumerico','requerido','forma'),
					'terminal'=>array('alfanumerico','requerido','mayuscula'),
					'forma_terminal'=>array('alfanumerico','requerido','forma'),
					'proveedor'=>array('alfanumerico','requerido','mayuscula'),
					'forma_proveedor'=>array('alfanumerico','requerido','forma'),
					'tipo_producto'=>array('alfanumerico','requerido','mayuscula'),
					'forma_tipo_producto'=>array('alfanumerico','requerido','forma'),
					'producto'=>array('alfanumerico','requerido','mayuscula'),
					'forma_producto'=>array('alfanumerico','requerido','forma'),
					'tipo_habitacion'=>array('alfanumerico','requerido','mayuscula'),
					'forma_tipo_habitacion'=>array('alfanumerico','requerido','forma'),
					'hotel'=>array('alfanumerico','requerido','mayuscula'),
					'forma_hotel'=>array('alfanumerico','requerido','forma'),
					'grupo'=>array('alfanumerico','requerido','mayuscula'),
					'forma_grupo'=>array('alfanumerico','requerido','forma'),
					'venta'=>array('alfanumerico','requerido','mayuscula'),
					'forma_venta'=>array('alfanumerico','requerido','forma'),
					'cotizacion'=>array('alfanumerico','requerido','mayuscula'),
					'forma_cotizacion'=>array('alfanumerico','requerido','forma'),
					'tipo_gasto'=>array('alfanumerico','requerido','mayuscula'),
					'forma_tipo_gasto'=>array('alfanumerico','requerido','forma'),
				);
	}
	if($tabla=="administradores_sistema"){
		$tabla;
		$tabla="empleados";
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
					'apellido_paterno'=>array('alfanumerico','requerido'),
					'apellido_materno'=>array('alfanumerico','requerido'),
					'correo_electronico'=>array('correo_electronico','requerido'),
					'usuario'=>array('alfanumerico','requerido','unique','unique_db_usuario',''),
					'password'=>array('alfanumerico','requerido'),
					'status'=>array('status','requerido'),
				);
	}
	if($tabla=="empleados"){
		$tabla="empleados";
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
					'apellido_paterno'=>array('alfanumerico','requerido'),
					'apellido_materno'=>array('alfanumerico','requerido'),
					'correo_electronico'=>array('correo_electronico','requerido'),
					'usuario'=>array('alfanumerico','requerido','unique','unique_db_usuario',''),
					'password'=>array('alfanumerico','requerido'),
					'status'=>array('status','requerido'),
				);
	}
	if($tabla=="tipos_productos"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
				);
	}
	if($tabla=="productos"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
					'clave_tipos_productos'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
				);
	}
	if($tabla=="tipos_habitaciones"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
				);
	}
	if($tabla=="hoteles"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
				);
	}
	if($tabla=="proveedores"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
					'correo_electronico'=>array('correo_electronico','requerido'),
					'telefono'=>array('telefono','requerido'),
				);
	}
	if($tabla=="grupos"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
					'clave_sucursales'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_clientes'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'fecha'=>array('fecha','requerido'),
					'hora'=>array('hora','requerido'),
					'check_in'=>array('fecha','requerido','check_in'),
					'check_out'=>array('fecha','','check_out'),
				);
	}
	if($tabla=="ventas"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'clave_sucursales'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_agentes'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_clientes'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'fecha'=>array('fecha','requerido'),
					'hora'=>array('hora','requerido'),
					'check_in'=>array('fecha','requerido','check_in'),
					'check_out'=>array('fecha','requerido','check_out'),
					'adultos'=>array('numerico','requerido'),
					'juniors'=>array('numerico','requerido'),
					'menores'=>array('numerico','requerido'),
					'clave_grupos'=>array('alfanumerico','requerido_opcional','buscar_clave','mayuscula'),
				);
	}
	if($tabla=="ventas_productos"){
		$columnData = array(
					'clave_ventas'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_tipos_productos'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_productos'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_tipos_habitaciones'=>array('alfanumerico','requerido_opcional','buscar_clave','mayuscula'),
					'clave_proveedores'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'codigo_reserva'=>array('alfanumerico','requerido','','mayuscula'),
					'monto_publico'=>array('moneda','requerido','','operacion_suma'),
					'monto_proveedor'=>array('moneda','requerido','','operacion_resta'),
					'monto_comision'=>array('moneda','requerido','','operacion_resultado'),
					'cantidad'=>array('numerico','requerido'),

				);
	}
	if($tabla=="ventas_pasajeros"){
		$columnData = array(
					'clave_ventas'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_clientes'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'fecha_nacimiento'=>array('fecha','requerido'),
					'nombre'=>array('alfanumerico','requerido'),
					'apellido_paterno'=>array('alfanumerico','requerido'),
					'apellido_materno'=>array('alfanumerico','requerido'),
					'correo_electronico'=>array('correo_electronico','requerido_opcional'),
					'telefono'=>array('telefono','requerido_opcional'),
					'celular'=>array('telefono','requerido_opcional'),
				);
	}

	if($tabla=="bancos"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
					'tipo_cuenta'=>array('alfanumerico','requerido','tipo_cuenta'),
					'monto_inicial'=>array('moneda','requerido','',''),
					'clabe'=>array('alfanumerico','requerido'),
					'numero_cuenta'=>array('alfanumerico','requerido'),
					'mostrar'=>array('alfanumerico',''),

				);
	}
	if($tabla=="terminales"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'clave_bancos'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_sucursales'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'folio'=>array('alfanumerico','requerido'),
					'nombre'=>array('alfanumerico','requerido'),
					'comision'=>array('numerico','requerido'),
				);
	}
	if($tabla=="tipos_gastos"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'nombre'=>array('alfanumerico','requerido'),
				);
	}
	if($tabla=="pagos_clientes"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','unique_db','mayuscula'),
					'clave_ventas'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_sucursales'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'fecha'=>array('fecha','requerido'),
					'hora'=>array('hora','requerido'),
					'tipo_pago'=>array('alfanumerico','requerido','tipo_pago'),
					'clave_bancos'=>array('alfanumerico','banco_opcional','buscar_clave','mayuscula'),
					'clave_terminales'=>array('alfanumerico','terminal_opcional','buscar_clave','mayuscula'),
					'transferencia'=>array('alfanumerico','requerido_opcional','mayuscula'),
					'monto'=>array('moneda','requerido','','operacion_suma'),
					'detalle'=>array('alfanumerico','requerido_opcional'),
					'aplicado'=>array('alfanumerico','aplicado','requerido',),
					'clave_proveedores'=>array('alfanumerico','proveedor_opcional','buscar_clave','mayuscula'),
					'estatus_facturacion'=>array('alfanumerico','status_facturacion','requerido_opcional',),

				);
	}
	if($tabla=="pagos_proveedores"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','','mayuscula'),
					'clave_ventas'=>array('alfanumerico','','buscar_clave','mayuscula'),
					'clave_proveedores'=>array('alfanumerico','requerido','buscar_clave','mayuscula','valor_igual'),
					'clave_sucursales'=>array('alfanumerico','','buscar_clave','mayuscula'),
					'fecha'=>array('fecha',''),
					'hora'=>array('hora',''),
					'tipo_pago'=>array('alfanumerico','requerido','tipo_pago'),
					'clave_bancos'=>array('alfanumerico','banco_opcional','buscar_clave','mayuscula'), 
					'transferencia'=>array('alfanumerico','requerido_opcional','mayuscula'),
					'monto'=>array('moneda','requerido','','operacion_suma'),
					'detalle'=>array('alfanumerico','requerido_opcional'),
					'abono_cuenta'=>array('alfanumerico','requerido_opcional','respuesta_si'),
					'estatus_facturacion'=>array('alfanumerico','status_facturacion','requerido_opcional',),

				);
	}

	if($tabla=="gastos"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','','mayuscula'),
					'fecha'=>array('fecha','requerido'),
					'hora'=>array('hora','requerido'),
					'clave_sucursales'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_agentes'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_tipos_gastos'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'tipo_pago'=>array('alfanumerico','requerido','tipo_pago'),
					'clave_bancos'=>array('alfanumerico','banco_opcional','buscar_clave','mayuscula'),
					'transferencia'=>array('alfanumerico','requerido_opcional','mayuscula'),
					'folio'=>array('alfanumerico','requerido_opcional','mayuscula'),
					'factura'=>array('alfanumerico','','mayuscula'),
					'monto'=>array('moneda','requerido','',''),
					'detalle'=>array('alfanumerico','requerido_opcional'),
					'tipo'=>array('alfanumerico','requerido','gasto_operacion'),
				);
	}
	if($tabla=="pagos_proveedores_comisiones"){
		$tabla="pagos_proveedores";
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','','mayuscula'),
					'clave_ventas'=>array('alfanumerico','','buscar_clave','mayuscula','valor_igual'),
					'clave_proveedores'=>array('alfanumerico','requerido','buscar_clave','mayuscula',''),
					'clave_ventas_saldos'=>array('alfanumerico','requerido','buscar_clave','mayuscula'),
					'clave_sucursales'=>array('alfanumerico','','buscar_clave','mayuscula'),
					'fecha'=>array('fecha',''),
					'hora'=>array('hora',''),
					'monto'=>array('moneda','requerido','','operacion_suma'),
					'detalle'=>array('alfanumerico','requerido_opcional'),
				);
	}
	if($tabla=="abonos_bancos"){
		$columnData = array(
					'clave'=>array('alfanumerico','requerido','unique','','mayuscula'),
					'clave_bancos'=>array('alfanumerico','banco_opcional','buscar_clave','mayuscula'),
					'clave_sucursales'=>array('alfanumerico','','buscar_clave','mayuscula'),
					'tipo_pago'=>array('alfanumerico','requerido','tipo_pago'),
					'clave_bancos_recursos'=>array('alfanumerico','','buscar_clave','mayuscula'),
					'transferencia'=>array('alfanumerico','requerido_opcional','mayuscula'),
					'fecha'=>array('fecha',''),
					'hora'=>array('hora',''),
					'monto'=>array('moneda','requerido','','operacion_suma'),
					'detalle'=>array('alfanumerico','requerido_opcional'),
				);
	}
	function password($password){
		$len = strlen($password);
		$return="";
		for ($i=0; $i < $len ; $i++) { 
			$return.="*";
		}
		return $return;
	}

	$csvFile = fopen($file, 'r');
	$tipo=1;
	if($tipo==1){
		$num=0;
		$countdraw=0;
		while(($line = fgetcsv($csvFile)) !== FALSE){
			$countdraw = $countdraw +1;
			if($countdraw > 1){
				$numx=0;
				//decalaramos todo lo que debe comenzar en la fila como para hacer calculos
				$monto=0;
				//sacamos las columnas y verificmos si cumple
				foreach ($columnData as $key => $value) {
					//esto es el valor del csv
					$line_valor=trim($line[$numx]);
					//esto es el nombre de la dato
					$key;
					//este es el tipo de dato
					$value;
					//validaciones
					if($key=="password"){
						$line_valor=password($line_valor);
					}
					//metemos el valor para el data
					$data[$num][$key]=$line_valor;
					//$data[$num][$key]=$line_valor;
					$numx=$numx+1;
				}
			}
			$num=$num+1;
		}
	}
	//cerramos el csvs
	fclose($csvFile);
	echo "<table id='importacion-tabla'   class='table table-striped table-bordered nowrap' width='100%' style='text-transform:none' > ";
	echo "<thead>";
	echo "<tr>";
	foreach ($columnData as $key => $value) {
		//echo "<td style='padding: 5px 5px 5px 10px;background-color: #0f9ed6;color:white;'>".strtoupper(str_replace('_',' ',$key))."</td>";
		echo "<th>".strtoupper(str_replace('_',' ',$key))."</th>";
	}
	echo "</tr>";
	echo "</thead>";
	echo "<tbody>";
	$num=1;
	foreach ($data as $keyT => $atribute) {
		if($keyT>1){
			echo "<tr>";
			foreach ($columnData as $key => $value) {
				echo "<td><div style='text-transform: none;' >{$atribute[$key]}</div></td>";
			}
			echo "</tr>";
		}
		
	}
	echo "</tbody>";
	echo "</table>";
		?>
	</div>
</div>