<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php
		function password($password){
			$len = strlen($password);
			$return="";
			for ($i=0; $i < $len ; $i++) { 
				$return.="*";
			}
			return $return;
		}
		if($operacion=="Insert"){
			$sql="SELECT *,
			(SELECT p.pais FROM paises p WHERE p.id=s.id_pais) pais,
			(SELECT p.estado FROM estados p WHERE p.id=s.id_estado) estado,
			(SELECT p.municipio FROM municipios p WHERE p.id=s.id_municipio) municipio,
			(SELECT p.localidad FROM localidades p WHERE p.id=s.id_localidad) localidad 
			FROM sucursales_historicos s  WHERE s.id_sucursal ='{$id}' AND s.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_sucursal']);
			unset($row['id_localidad']);
			unset($row['id_estado']);
			unset($row['id_pais']);
			unset($row['id_municipio']);
			unset($row['codigo_plataforma']);  
			unset($row['referencia_importacion']);
			unset($row['status']);
			unset($row['longitud']);
			unset($row['latitud']);
			unset($row['fechaR']); 
			$rowx=$row;
		}
		if($operacion=="Update"){
			$sql="SELECT *,
			(SELECT p.pais FROM paises p WHERE p.id=s.id_pais) pais,
			(SELECT p.estado FROM estados p WHERE p.id=s.id_estado) estado,
			(SELECT p.municipio FROM municipios p WHERE p.id=s.id_municipio) municipio,
			(SELECT p.localidad FROM localidades p WHERE p.id=s.id_localidad) localidad 
			FROM sucursales_historicos s  WHERE s.id_sucursal ='{$id}' AND s.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_sucursal']);
			unset($row['id_localidad']);
			unset($row['id_estado']);
			unset($row['id_pais']);
			unset($row['id_municipio']);
			unset($row['codigo_plataforma']);  
			unset($row['referencia_importacion']);
			unset($row['status']);
			unset($row['longitud']);
			unset($row['latitud']);
			unset($row['fechaR']);


			$sql="SELECT *,
			(SELECT p.pais FROM paises p WHERE p.id=s.id_pais) pais,
			(SELECT p.estado FROM estados p WHERE p.id=s.id_estado) estado,
			(SELECT p.municipio FROM municipios p WHERE p.id=s.id_municipio) municipio,
			(SELECT p.localidad FROM localidades p WHERE p.id=s.id_localidad) localidad 
			FROM sucursales_historicos s  WHERE s.id_sucursal ='{$id}' AND s.fechaR<'{$fechaR}' ORDER BY s.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$rowx=$resultado->fetch_assoc();
			foreach($rowx as $key => $value){
				if(is_numeric($key)) unset($rowx[$key]);
			}
			//var_dump($row);
			unset($rowx['id']);
			unset($rowx['id_sucursal']);
			unset($rowx['id_localidad']);
			unset($rowx['id_estado']);
			unset($rowx['id_pais']);
			unset($rowx['id_municipio']);
			unset($rowx['codigo_plataforma']);  
			unset($rowx['referencia_importacion']);
			unset($rowx['status']);
			unset($rowx['longitud']);
			unset($rowx['latitud']);
			unset($rowx['fechaR']);
		}
		if($operacion=="Delete"){
			$sql="SELECT *,
			(SELECT p.pais FROM paises p WHERE p.id=s.id_pais) pais,
			(SELECT p.estado FROM estados p WHERE p.id=s.id_estado) estado,
			(SELECT p.municipio FROM municipios p WHERE p.id=s.id_municipio) municipio,
			(SELECT p.localidad FROM localidades p WHERE p.id=s.id_localidad) localidad 
			FROM sucursales_historicos s  WHERE s.id_sucursal ='{$id}' AND s.fechaR<'{$fechaR}' ORDER BY s.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_sucursal']);
			unset($row['id_localidad']);
			unset($row['id_estado']);
			unset($row['id_pais']);
			unset($row['id_municipio']);
			unset($row['codigo_plataforma']);  
			unset($row['referencia_importacion']);
			unset($row['status']);
			unset($row['longitud']);
			unset($row['latitud']);
			unset($row['fechaR']);
			$rowx=$row;
		}
		?>
		<br>
		<?php
			if($operacion=="Delete"){
				$tipoRegistro="Borrado";
			}else{
				$tipoRegistro="Actual";
			}
			echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>{$tipoRegistro}</label></div>";
			foreach ($row as $key => $value) {
				echo '<label class="labelForm">';
				if($rowx[$key]!=$value){
					$color="color:red;";
				}else{
					$color="";
				}
				if($key=='password'){
					$value=password($value);
				}
				$key=str_replace("_"," ",$key); 
				echo "<font style='font-size: 10px;'>{$key}:</font>";
				echo '</label>';
				echo '<label class="descripcionForm">'; 
				
				echo "<font style='font-size: 10px;{$color}'>{$value}</font>";
				echo '</label>';
				echo "<br>";
			}
		?>
		<hr>

		<?php
			if($operacion=="Update"){
				echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>Anterior</label></div>";
				foreach ($rowx as $key => $value) {
					if($key=='password'){
						$value=password($value);
					}
					echo '<label class="labelForm">';
					$key=str_replace("_"," ",$key); 
					echo "<font style='font-size: 10px;'>{$key}:</font>";
					echo '</label>';
					echo '<label class="descripcionForm">'; 
					echo "<font style='font-size: 10px;'>{$value}</font>";
					echo '</label>';
					echo "<br>";
				}
			}
		?>

	</div>
</div>