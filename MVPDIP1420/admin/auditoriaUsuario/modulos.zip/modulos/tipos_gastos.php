<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php
		function password($password){
			$len = strlen($password);
			$return="";
			for ($i=0; $i < $len ; $i++) { 
				$return.="*";
			}
			return $return;
		}
		if($operacion=="Insert"){
			$sql="SELECT * 
			FROM tipos_gastos_historicos th  WHERE th.id_tipo_gasto ='{$id}' AND th.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_tipo_gasto']); 

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']); 
			$rowx=$row;
		}
		if($operacion=="Update"){
			$sql="SELECT *  
			FROM tipos_gastos_historicos th  WHERE th.id_tipo_gasto ='{$id}' AND th.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_tipo_gasto']); 

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']); 


			$sql="SELECT *  
			FROM tipos_gastos_historicos th  WHERE th.id_tipo_gasto ='{$id}' AND th.fechaR<'{$fechaR}' ORDER BY th.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$rowx=$resultado->fetch_assoc();
			foreach($rowx as $key => $value){
				if(is_numeric($key)) unset($rowx[$key]);
			}
			//var_dump($row);
			unset($rowx['id']);
			unset($rowx['id_tipo_gasto']); 

			unset($rowx['referencia_importacion']);
			unset($rowx['codigo_plataforma']);
			unset($rowx['fechaR']); 
		}
		if($operacion=="Delete"){
			$sql="SELECT *  
			FROM tipos_gastos_historicos th  WHERE th.id_tipo_gasto ='{$id}' AND th.fechaR<'{$fechaR}' ORDER BY th.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_tipo_gasto']); 

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']);
			$rowx=$row;
		}
		?>
		<br>
		<?php
			if($operacion=="Delete"){
				$tipoRegistro="Borrado";
			}else{
				$tipoRegistro="Actual";
			}
			echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>{$tipoRegistro}</label></div>";
			foreach ($row as $key => $value) {
				echo '<label class="labelForm">';
				if($rowx[$key]!=$value){
					$color="color:red;";
				}else{
					$color="";
				}
				if($key=='password'){
					$value=password($value);
				}
				$key=str_replace("_"," ",$key); 
				echo "<font style='font-size: 10px;'>{$key}:</font>";
				echo '</label>';
				echo '<label class="descripcionForm">'; 
				
				echo "<font style='font-size: 10px;{$color}'>{$value}</font>";
				echo '</label>';
				echo "<br>";
			}
		?>
		<hr>

		<?php
			if($operacion=="Update"){
				echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>Anterior</label></div>";
				foreach ($rowx as $key => $value) {
					if($key=='password'){
						$value=password($value);
					}
					echo '<label class="labelForm">';
					$key=str_replace("_"," ",$key); 
					echo "<font style='font-size: 10px;'>{$key}:</font>";
					echo '</label>';
					echo '<label class="descripcionForm">'; 
					echo "<font style='font-size: 10px;'>{$value}</font>";
					echo '</label>';
					echo "<br>";
				}
			}
		?>

	</div>
</div>