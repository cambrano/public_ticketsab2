<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php
		function password($password){
			$len = strlen($password);
			$return="";
			for ($i=0; $i < $len ; $i++) { 
				$return.="*";
			}
			return $return;
		}
		if($operacion=="Insert"){

			$sql="
			SELECT 
			(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno) FROM empleados e LEFT JOIN usuarios u ON e.id = u.id_empleado WHERE u.id = um.id_usuario) nombre_empleado ,
			(SELECT s.seccion FROM secciones s WHERE s.id=um.id_seccion ) seccion ,
			(SELECT m.modulo FROM modulos m WHERE m.id=um.id_modulo ) modulo 
			FROM usuarios_modulos_historicos um WHERE um.id_usuario_modulo = '{$id}' AND um.fechaR = '{$fechaR}'";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_usuario_modulo']); 
			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']); 
			$rowx=$row;
			$sql="SELECT 
			(
			CASE
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='view' THEN 'vista'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='insert' THEN 'inserción'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='update' THEN 'modificación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='delete' THEN 'eliminación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='download' THEN 'descarga'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='all' THEN 'total'
			END
			) permiso,
			IF(up.status=1,'Activo','No Activo') status
			FROM usuarios_permisos_historicos up 
			WHERE up.id_usuario_modulo='{$id}' AND up.fechaR='{$fechaR}' ORDER BY up.id_permiso DESC ";
			$resultado = $conexion->query($sql);
			$result = $conexion->query($sql); 
			$num=0; 
			while($rowc=$result->fetch_assoc()){
				foreach($rowc as $key => $value){
					if(is_numeric($key)) unset($rowc[$key]);
				}
				$datos[$num]=$rowc;
				$num=$num+1;
			}

			$datosx=$datos;
		}
		if($operacion=="Update"){
			$sql="
			SELECT 
			(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno) FROM empleados e LEFT JOIN usuarios u ON e.id = u.id_empleado WHERE u.id = um.id_usuario) nombre_empleado ,
			(SELECT s.seccion FROM secciones s WHERE s.id=um.id_seccion ) seccion ,
			(SELECT m.modulo FROM modulos m WHERE m.id=um.id_modulo ) modulo 
			FROM usuarios_modulos_historicos um WHERE um.id_usuario_modulo = '{$id}' AND um.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_usuario_modulo']); 
			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']); 

			$sql="SELECT 
			(
			CASE
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='view' THEN 'vista'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='insert' THEN 'inserción'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='update' THEN 'modificación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='delete' THEN 'eliminación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='download' THEN 'descarga'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='all' THEN 'total'
			END
			) permiso,
			IF(up.status=1,'Activo','No Activo') status
			FROM usuarios_permisos_historicos up 
			WHERE up.id_usuario_modulo='{$id}' ORDER BY up.id_permiso DESC ";
			$resultado = $conexion->query($sql);
			$result = $conexion->query($sql); 
			$num=0; 
			while($rowc=$result->fetch_assoc()){
				foreach($rowc as $key => $value){
					if(is_numeric($key)) unset($rowc[$key]);
				}
				$datos[$num]=$rowc;
				$num=$num+1;
			}


			$sql="SELECT 
			(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno) FROM empleados e LEFT JOIN usuarios u ON e.id = u.id_empleado WHERE u.id = um.id_usuario) nombre_empleado ,
			(SELECT s.seccion FROM secciones s WHERE s.id=um.id_seccion ) seccion ,
			(SELECT m.modulo FROM modulos m WHERE m.id=um.id_modulo ) modulo 
			FROM usuarios_modulos_historicos um WHERE um.id_usuario_modulo = '{$id}' AND  um.fechaR<'{$fechaR}' ORDER BY um.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$rowx=$resultado->fetch_assoc();
			foreach($rowx as $key => $value){
				if(is_numeric($key)) unset($rowx[$key]);
			}
			//var_dump($row);
			unset($rowx['id']);
			unset($rowx['id_usuario_modulo']); 
			unset($rowx['referencia_importacion']);
			unset($rowx['codigo_plataforma']);
			unset($rowx['fechaR']); 

			$sql="SELECT 
			(
			CASE
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='view' THEN 'vista'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='insert' THEN 'inserción'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='update' THEN 'modificación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='delete' THEN 'eliminación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='download' THEN 'descarga'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='all' THEN 'total'
			END
			) permiso,
			IF(up.status=1,'Activo','No Activo') status
			FROM usuarios_permisos_historicos up 
			WHERE up.id_usuario_modulo='{$id}' AND up.fechaR<'{$fechaR}' ORDER BY up.id_permiso DESC ";
			$resultado = $conexion->query($sql);
			$result = $conexion->query($sql); 
			$num=0; 
			while($rowc=$result->fetch_assoc()){
				foreach($rowc as $key => $value){
					if(is_numeric($key)) unset($rowc[$key]);
				}
				$datosx[$num]=$rowc;
				$num=$num+1;
			}





		}
		if($operacion=="Delete"){
			$sql="SELECT 
			(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno) FROM empleados e LEFT JOIN usuarios u ON e.id = u.id_empleado WHERE u.id = um.id_usuario) nombre_empleado ,
			(SELECT s.seccion FROM secciones s WHERE s.id=um.id_seccion ) seccion ,
			(SELECT m.modulo FROM modulos m WHERE m.id=um.id_modulo ) modulo 
			FROM usuarios_modulos_historicos um WHERE um.id_usuario_modulo = '{$id}' AND  um.fechaR<'{$fechaR}' ORDER BY um.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_usuario_modulo']); 

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']);
			$rowx=$row;
			$sql="SELECT 
			(
			CASE
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='view' THEN 'vista'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='insert' THEN 'inserción'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='update' THEN 'modificación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='delete' THEN 'eliminación'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='download' THEN 'descarga'
			WHEN (SELECT p.permiso FROM permisos p WHERE p.id=up.id_permiso)='all' THEN 'total'
			END
			) permiso,
			IF(up.status=1,'Activo','No Activo') status
			FROM usuarios_permisos_historicos up 
			WHERE up.id_usuario_modulo='{$id}' GROUP BY up.id_permiso ORDER BY up.id_permiso DESC ";
			$resultado = $conexion->query($sql);
			$result = $conexion->query($sql); 
			$num=0; 
			while($rowc=$result->fetch_assoc()){
				foreach($rowc as $key => $value){
					if(is_numeric($key)) unset($rowc[$key]);
				}
				$datos[$num]=$rowc;
				$num=$num+1;
			}
			$datosx=$datos;

		}
		?>
		<br>
		<?php
			if($operacion=="Delete"){
				$tipoRegistro="Borrado";
			}else{
				$tipoRegistro="Actual";
			}
			echo "<div style='widum:100%;text-align:center'><label class='labelForm' id='labeltemaname'>{$tipoRegistro}</label></div>";
			foreach ($row as $key => $value) {
				echo '<label class="labelForm">';
				if($rowx[$key]!=$value){
					$color="color:red;";
				}else{
					$color="";
				}
				if($key=='password'){
					$value=password($value);
				}
				$key=str_replace("_"," ",$key); 
				echo "<font style='font-size: 10px;'>{$key}:</font>";
				echo '</label>';
				echo '<label class="descripcionForm">'; 
				
				echo "<font style='font-size: 10px;{$color}'>{$value}</font>";
				echo '</label>';
				echo "<br>";
			}
			echo "Permisos";
			echo "<br>";
			foreach ($datos as $keyR => $value) {
				foreach ($value as $key => $valuex) {
					echo '<label class="labelForm">';
					if($datosx[$keyR][$key]!=$valuex){
						//$color="color:red;";
					}else{
						$color="";
					}
					$key=str_replace("_"," ",$key); 
					echo "<font style='font-size: 10px;'>{$key}:</font>";
					echo '</label>';
					echo '<label class="descripcionForm">'; 
					
					echo "<font style='font-size: 10px;{$color}'>{$valuex}</font>";
					echo '</label>';
					echo "<br>";
				}
			}
		?>
		<hr>

		<?php
			if($operacion=="Update"){
				echo "<div style='widum:100%;text-align:center'><label class='labelForm' id='labeltemaname'>Anterior</label></div>";
				foreach ($rowx as $key => $value) {
					if($key=='password'){
						$value=password($value);
					}
					echo '<label class="labelForm">';
					$key=str_replace("_"," ",$key); 
					echo "<font style='font-size: 10px;'>{$key}:</font>";
					echo '</label>';
					echo '<label class="descripcionForm">'; 
					echo "<font style='font-size: 10px;'>{$value}</font>";
					echo '</label>';
					echo "<br>";
				}
				echo "Permisos";
				echo "<br>";
				foreach ($datosx as $keyR => $value) {
					foreach ($value as $key => $valuex) {
						echo '<label class="labelForm">';
						if($datosx[$keyR][$key]!=$valuex){
							//$color="color:red;";
						}else{
							$color="";
						}
						$key=str_replace("_"," ",$key); 
						echo "<font style='font-size: 10px;'>{$key}:</font>";
						echo '</label>';
						echo '<label class="descripcionForm">'; 
						
						echo "<font style='font-size: 10px;{$color}'>{$valuex}</font>";
						echo '</label>';
						echo "<br>";
					}
				}
			}
		?>

	</div>
</div>