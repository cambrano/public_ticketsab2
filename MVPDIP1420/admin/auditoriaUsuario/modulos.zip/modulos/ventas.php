<div class="bodymanager" id="bodymanager"> 
	<div id="mensaje" class="mensajeSolo" ><br></div>
	<div class="bodyform">
		<div class= "bodyheader">
			<label class="tituloForm">
				<font style="font-size: 25px;"><?= tipoOperacion($operacion) ."<br>".moduloNombreLog($tabla) ?></font>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $fechaR ?></font><br>
			</label><br>
			<label class="tituloForm">
				<font style="font-size: 13px;"><?= $nombre_usuario ?></font><br>
			</label><br><br>
		</div>
	</div>
	<div class="bodyinput">
		<?php
		function password($password){
			$len = strlen($password);
			$return="";
			for ($i=0; $i < $len ; $i++) { 
				$return.="*";
			}
			return $return;
		}
		if($operacion=="Insert"){
			$sql="SELECT * ,
			(SELECT s.nombre FROM sucursales s WHERE s.id=vt.id_sucursal) sucursal,
			(
				SELECT
					IF(
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) IS NULL,
						u.usuario,
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) 
					)
					 nombreCompledo 

					FROM usuarios u WHERE u.id=vt.id_usuario AND (u.codigo_plataforma='{$codigo_plataforma}' OR u.codigo_plataforma='x') 
			) agente,
			(SELECT CONCAT_WS(' ',c.nombre,c.apellido_paterno,c.apellido_materno)  FROM clientes c WHERE c.id=vt.id_cliente) cliente,
			(SELECT g.nombre FROM grupos g WHERE g.id=vt.id) Grupo
			FROM ventas_historicos vt  WHERE vt.id_venta ='{$id}' AND vt.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_venta']);
			unset($row['status']);
			unset($row['status_asignado']);
			unset($row['status_proveedor']);
			unset($row['status_comision']); 
			unset($row['id_sucursal']);
			unset($row['nombre_cliente']);
			unset($row['fecha_hora']);
			unset($row['id_usuario']);
			unset($row['id_grupo']);

			

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']); 
			$rowx=$row;
		}
		if($operacion=="Update"){
			$sql="SELECT * ,
			(SELECT s.nombre FROM sucursales s WHERE s.id=vt.id_sucursal) sucursal,
			(
				SELECT
					IF(
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) IS NULL,
						u.usuario,
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) 
					)
					 nombreCompledo 

					FROM usuarios u WHERE u.id=vt.id_usuario AND (u.codigo_plataforma='{$codigo_plataforma}' OR u.codigo_plataforma='x') 
			) agente,
			(SELECT CONCAT_WS(' ',c.nombre,c.apellido_paterno,c.apellido_materno)  FROM clientes c WHERE c.id=vt.id_cliente) cliente,
			(SELECT g.nombre FROM grupos g WHERE g.id=vt.id) Grupo
			FROM ventas_historicos vt  WHERE vt.id_venta ='{$id}' AND vt.fechaR='{$fechaR}' ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_venta']);
			unset($row['status']);
			unset($row['status_asignado']);
			unset($row['status_proveedor']);
			unset($row['status_comision']); 
			unset($row['id_sucursal']);
			unset($row['nombre_cliente']);
			unset($row['fecha_hora']);
			unset($row['id_usuario']);
			unset($row['id_grupo']);
			

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']); 


			$sql="SELECT * ,
			(SELECT s.nombre FROM sucursales s WHERE s.id=vt.id_sucursal) sucursal,
			(
				SELECT
					IF(
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) IS NULL,
						u.usuario,
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) 
					)
					 nombreCompledo 

					FROM usuarios u WHERE u.id=vt.id_usuario AND (u.codigo_plataforma='{$codigo_plataforma}' OR u.codigo_plataforma='x') 
			) agente,
			(SELECT CONCAT_WS(' ',c.nombre,c.apellido_paterno,c.apellido_materno)  FROM clientes c WHERE c.id=vt.id_cliente) cliente,
			(SELECT g.nombre FROM grupos g WHERE g.id=vt.id) Grupo
			FROM ventas_historicos vt  WHERE vt.id_venta ='{$id}' AND vt.fechaR<'{$fechaR}' ORDER BY vt.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$rowx=$resultado->fetch_assoc();
			foreach($rowx as $key => $value){
				if(is_numeric($key)) unset($rowx[$key]);
			}
			//var_dump($row);
			unset($rowx['id']);
			unset($rowx['id_venta']);
			unset($rowx['status']);
			unset($rowx['status_asignado']);
			unset($rowx['status_proveedor']);
			unset($rowx['status_comision']); 
			unset($rowx['id_sucursal']);
			unset($rowx['nombre_cliente']);
			unset($rowx['fecha_hora']);
			unset($rowx['id_usuario']);
			unset($rowx['id_grupo']);

			unset($rowx['referencia_importacion']);
			unset($rowx['codigo_plataforma']);
			unset($rowx['fechaR']); 
		}
		if($operacion=="Delete"){
			$sql="SELECT * ,
			(SELECT s.nombre FROM sucursales s WHERE s.id=vt.id_sucursal) sucursal,
			(
				SELECT
					IF(
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) IS NULL,
						u.usuario,
						(SELECT CONCAT_WS(' ',e.nombre,e.apellido_paterno,e.apellido_materno)  FROM empleados e WHERE e.id=u.id_empleado) 
					)
					 nombreCompledo 

					FROM usuarios u WHERE u.id=vt.id_usuario AND (u.codigo_plataforma='{$codigo_plataforma}' OR u.codigo_plataforma='x') 
			) agente,
			(SELECT CONCAT_WS(' ',c.nombre,c.apellido_paterno,c.apellido_materno)  FROM clientes c WHERE c.id=vt.id_cliente) cliente,
			(SELECT g.nombre FROM grupos g WHERE g.id=vt.id) Grupo
			FROM ventas_historicos vt  WHERE vt.id_venta ='{$id}' AND vt.fechaR<'{$fechaR}' ORDER BY vt.fechaR DESC ";
			$resultado = $conexion->query($sql);
			$row=$resultado->fetch_assoc();
			foreach($row as $key => $value){
				if(is_numeric($key)) unset($row[$key]);
			}
			//var_dump($row);
			unset($row['id']);
			unset($row['id_venta']);
			unset($row['status']);
			unset($row['status_asignado']);
			unset($row['status_proveedor']);
			unset($row['status_comision']); 
			unset($row['id_sucursal']);
			unset($row['nombre_cliente']);
			unset($row['fecha_hora']);
			unset($row['id_usuario']);
			unset($row['id_grupo']);
			

			unset($row['referencia_importacion']);
			unset($row['codigo_plataforma']);
			unset($row['fechaR']);
			$rowx=$row;
		}
		?>
		<br>
		<?php
			if($operacion=="Delete"){
				$tipoRegistro="Borrado";
			}else{
				$tipoRegistro="Actual";
			}
			echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>{$tipoRegistro}</label></div>";
			foreach ($row as $key => $value) {
				echo '<label class="labelForm">';
				if($rowx[$key]!=$value){
					$color="color:red;";
				}else{
					$color="";
				}
				if($key=='password'){
					$value=password($value);
				}
				if($key=="fecha_llegada"){
					$key="CHECK IN";
				}
				if($key=="fecha_salida"){
					$key="CHECK OUT";
				}
				if($key=="monto_publico_total"){
					$value=number_format($value,2,'.',',');
				}
				if($key=="monto_proveedor_total"){
					$value=number_format($value,2,'.',',');
				}
				if($key=="monto_comision_total"){
					$value=number_format($value,2,'.',',');
				}
				$key=str_replace("_"," ",$key); 
				echo "<font style='font-size: 10px;'>{$key}:</font>";
				echo '</label>';
				echo '<label class="descripcionForm">'; 
				echo "<font style='font-size: 10px;{$color}'>{$value}</font>";
				echo '</label>';
				echo "<br>";
			}
		?>
		<hr>

		<?php
			if($operacion=="Update"){
				echo "<div style='width:100%;text-align:center'><label class='labelForm' id='labeltemaname'>Anterior</label></div>";
				foreach ($rowx as $key => $value) {
					if($key=='password'){
						$value=password($value);
					}
					if($key=="fecha_llegada"){
					$key="CHECK IN";
					}
					if($key=="fecha_salida"){
						$key="CHECK OUT";
					}
					if($key=="monto_publico_total"){
						$value=number_format($value,2,'.',',');
					}
					if($key=="monto_proveedor_total"){
						$value=number_format($value,2,'.',',');
					}
					if($key=="monto_comision_total"){
						$value=number_format($value,2,'.',',');
					}
					echo '<label class="labelForm">';
					$key=str_replace("_"," ",$key); 
					echo "<font style='font-size: 10px;'>{$key}:</font>";
					echo '</label>';
					echo '<label class="descripcionForm">'; 
					echo "<font style='font-size: 10px;'>{$value}</font>";
					echo '</label>';
					echo "<br>";
				}
			}
		?>

	</div>
</div>